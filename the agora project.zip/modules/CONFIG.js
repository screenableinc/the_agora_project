var STNs = {users:"agorans", orders:"orders", categories:"categories", products:"products", sub_categories:"sub_categories",
vendors:"businesses", product_images:"product_images", cart:"cart",locations:"locations"}
var gvs = {userAuthTokenName:"userAuth",businessAuthTokenName:"businessAuth"}

module.exports={
    STNs:STNs,
    gvs:gvs
}